package com.zarvimo.zvls

import android.os.Handler
import android.os.Looper
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.decoder.AudioDecoderInterface
import com.pedro.encoder.input.decoder.VideoDecoderInterface
import com.pedro.library.rtmp.RtmpFromFile

/**
 * Streams gallery clips (single loop or playlist) using RootEncoder's RtmpFromFile.
 * All RootEncoder file-streaming calls live in this one class.
 * Between playlist clips the RTMP connection is re-opened (short gap of 1-3 seconds).
 */
class FileStreamer(
    private val checker: ConnectChecker,
    private val onClip: (Int) -> Unit,
    private val onEnd: () -> Unit,
    private val onError: (String) -> Unit
) : VideoDecoderInterface, AudioDecoderInterface {

    private val handler = Handler(Looper.getMainLooper())
    private var rtmp: RtmpFromFile? = null
    private var clips: List<Clip> = emptyList()
    private var index = 0
    private var url = ""
    private var bitrate = 2_500_000
    private var loopOne = false
    private var repeatAll = true
    private var shuffle = false
    private var fails = 0
    private var active = false

    fun start(
        url: String, clips: List<Clip>, from: Int,
        loopOne: Boolean, repeatAll: Boolean, shuffle: Boolean, bitrate: Int
    ) {
        this.url = url
        this.clips = clips.toList()
        this.index = if (clips.isEmpty()) 0 else from.coerceIn(0, clips.size - 1)
        this.loopOne = loopOne
        this.repeatAll = repeatAll
        this.shuffle = shuffle
        this.bitrate = bitrate
        this.fails = 0
        this.active = true
        play()
    }

    fun setModes(loopOne: Boolean, repeatAll: Boolean, shuffle: Boolean) {
        this.loopOne = loopOne
        this.repeatAll = repeatAll
        this.shuffle = shuffle
        try {
            rtmp?.setLoopMode(loopOne)
        } catch (e: Exception) {
        }
    }

    fun restart() {
        if (!active) return
        stopCurrent()
        play()
    }

    fun stop() {
        active = false
        stopCurrent()
    }

    private fun stopCurrent() {
        val r = rtmp
        rtmp = null
        if (r != null) {
            try {
                if (r.isStreaming) r.stopStream()
            } catch (e: Exception) {
            }
        }
    }

    private fun play() {
        val clip = clips.getOrNull(index)
        if (clip == null) {
            active = false
            onEnd()
            return
        }
        val r = RtmpFromFile(checker, this, this)
        val ok = try {
            prepareVideoCompat(r, clip.path, bitrate)
        } catch (e: Exception) {
            false
        }
        if (!ok) {
            onError(clip.name)
            fails++
            if (fails >= clips.size) {
                active = false
                onEnd()
            } else {
                next()
            }
            return
        }
        try {
            r.prepareAudio(clip.path, 128 * 1024)
        } catch (e: Exception) {
            // file without usable audio: stream video only
        }
        r.setLoopMode(loopOne)
        rtmp = r
        fails = 0
        r.startStream(url)
        onClip(index)
    }

    /**
     * RootEncoder 2.4.x changed the prepareVideo overloads between releases, so the
     * String-path overload is looked up at runtime instead of being hard-coded.
     */
    private fun prepareVideoCompat(r: RtmpFromFile, path: String, bitrate: Int): Boolean {
        val m = r.javaClass.methods
            .filter { it.name == "prepareVideo" && it.parameterTypes.isNotEmpty() && it.parameterTypes[0] == String::class.java }
            .minByOrNull { it.parameterTypes.size } ?: return false
        var bitrateUsed = false
        val args = m.parameterTypes.mapIndexed { i, t ->
            when {
                i == 0 -> path
                t == Int::class.javaPrimitiveType && !bitrateUsed -> {
                    bitrateUsed = true
                    bitrate
                }
                t == Int::class.javaPrimitiveType -> 0
                t == Boolean::class.javaPrimitiveType -> false
                else -> null
            }
        }.toTypedArray()
        return try {
            (m.invoke(r, *args) as? Boolean) ?: false
        } catch (e: Exception) {
            false
        }
    }

    private fun next() {
        stopCurrent()
        val n = clips.size
        if (n == 0) {
            active = false
            onEnd()
            return
        }
        if (shuffle && n > 1) {
            var r = index
            while (r == index) r = (0 until n).random()
            index = r
        } else {
            index++
            if (index >= n) {
                if (repeatAll) {
                    index = 0
                } else {
                    active = false
                    onEnd()
                    return
                }
            }
        }
        play()
    }

    override fun onVideoDecoderFinished() {
        if (active && !loopOne) {
            handler.post { if (active && !loopOne) next() }
        }
    }

    override fun onAudioDecoderFinished() {}
}
