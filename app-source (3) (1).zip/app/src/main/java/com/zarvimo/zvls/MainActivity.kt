package com.zarvimo.zvls

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.video.CameraHelper
import com.pedro.library.rtmp.RtmpCamera2
import com.pedro.library.view.OpenGlView
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity(), ConnectChecker {

    private lateinit var sp: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var glView: OpenGlView
    private lateinit var camera: RtmpCamera2
    private lateinit var files: FileStreamer
    private val overlay = Overlay()
    private var camAdapt: BitrateAdapt? = null

    private lateinit var tvStatus: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvHint: TextView
    private lateinit var etServer: EditText
    private lateinit var etKey: EditText
    private lateinit var etTicker: EditText
    private lateinit var btnGo: TextView
    private lateinit var btnStartPl: TextView
    private lateinit var btnMute: ImageButton
    private lateinit var btnFlip: ImageButton
    private lateinit var btnFlash: ImageButton
    private lateinit var swMic: SwitchCompat
    private lateinit var swUse: SwitchCompat
    private lateinit var swLogo: SwitchCompat
    private lateinit var swTicker: SwitchCompat
    private lateinit var tvBitrate: TextView
    private lateinit var panelPlaylist: View
    private lateinit var panelSettings: View
    private lateinit var chips: List<TextView>
    private var setSrc: (Int) -> Unit = {}

    private val platformNames = listOf("YouTube", "Facebook", "Twitch", "Kick", "Custom")
    private val servers = listOf(
        "rtmp://a.rtmp.youtube.com/live2",
        "rtmps://live-api-s.facebook.com:443/rtmp",
        "rtmp://live.twitch.tv/app",
        "rtmps://fa723fc1b171.global-contribute.live-video.net:443/app",
        ""
    )
    private val resW = intArrayOf(854, 1280, 1920)
    private val resH = intArrayOf(480, 720, 1080)
    private val fpsVals = intArrayOf(24, 30, 60)

    // saved settings
    private var platform = 0
    private val useFlags = BooleanArray(5)
    private var res = 1
    private var fps = 1
    private var land = false
    private var kbps = 2500
    private var muted = false
    private var autoReconnect = true
    private var keepOn = true
    private var adaptive = true
    private var logoOn = false
    private var tickerOn = false
    private var tickerText = "Zarvimo Live Streamer"
    private var loopMode = false
    private var repeatAll = true
    private var shuffle = false
    private var cur = 0
    private var clips = mutableListOf<Clip>()

    // runtime state
    private var facing = CameraHelper.Facing.BACK
    private var gallery = false
    private var live = false
    private var connected = false
    private var reconnectPending = false
    private var liveStart = 0L
    private var urlInUse = ""
    private var flashOn = false
    private var askingPerms = false
    private var destNames: List<String> = emptyList()
    private val destUp = BooleanArray(5)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            askingPerms = false
            if (hasPerms()) startPreview() else toast(R.string.err_perm)
        }

    private val pickVideos =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            importVideos(uris)
        }

    private val pickLogo =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importLogo(uri)
        }

    private val ticker = object : Runnable {
        override fun run() {
            if (!live) return
            if (connected) {
                val s = (SystemClock.elapsedRealtime() - liveStart) / 1000
                tvStatus.text = getString(R.string.status_live) + "  " +
                    String.format(Locale.US, "%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
            }
            ui.postDelayed(this, 1000)
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = getSharedPreferences("zvls", MODE_PRIVATE)
        loadSettings()
        requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContentView(R.layout.activity_main)
        bindViews()

        camera = RtmpCamera2(glView, this)
        files = FileStreamer(object : FileStreamer.Callbacks {
            override fun onClip(index: Int) {
                onClipStarted(index)
            }

            override fun onEnd() {
                stopLive()
            }

            override fun onClipError(name: String) {
                toast(R.string.clip_failed, name)
            }

            override fun onDest(dest: Int, connected: Boolean, reason: String?) {
                onDestState(dest, connected, reason)
            }

            override fun onBitrate(totalBps: Long) {
                if (live) updateStats(totalBps)
            }

            override fun onAttach(stream: Any, w: Int, h: Int) {
                attachFileOverlay(stream, w, h)
            }

            override fun onDetach(stream: Any) {
                overlay.forget(stream)
            }
        })

        glView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {}
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                startPreview()
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                if (gallery) return
                if (live) stopLive()
                try {
                    if (camera.isOnPreview) camera.stopPreview()
                } catch (e: Exception) {
                }
            }
        })

        setupUi()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (panelPlaylist.visibility == View.VISIBLE || panelSettings.visibility == View.VISIBLE) {
                    nav(0)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        nav(0)
        loadDest()
        refreshChips()
        renderClips()
        updateStats()
        updateGoButtons()
        updateMuteUi()
        applyKeepOn()
        setStatus(0)
        if (!hasPerms()) askPerms()
    }

    override fun onPause() {
        saveDest()
        saveTicker()
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        if (live) stopLive()
        overlay.stopAll()
        try {
            if (camera.isOnPreview) camera.stopPreview()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        fitPreview()
        restartPreview()
    }

    // ------------------------------------------------------------------ UI setup

    private fun <T : View> v(id: Int): T = findViewById(id)

    private fun bindViews() {
        glView = v(R.id.glView)
        tvStatus = v(R.id.tvStatus)
        tvStats = v(R.id.tvStats)
        tvHint = v(R.id.tvHint)
        etServer = v(R.id.etServer)
        etKey = v(R.id.etKey)
        etTicker = v(R.id.etTicker)
        btnGo = v(R.id.btnGo)
        btnStartPl = v(R.id.btnStartPlaylist)
        btnMute = v(R.id.btnMute)
        btnFlip = v(R.id.btnFlip)
        btnFlash = v(R.id.btnFlash)
        swMic = v(R.id.swMic)
        swUse = v(R.id.swUse)
        swLogo = v(R.id.swLogo)
        swTicker = v(R.id.swTicker)
        tvBitrate = v(R.id.tvBitrate)
        panelPlaylist = v(R.id.panelPlaylist)
        panelSettings = v(R.id.panelSettings)
    }

    private fun group(items: List<TextView>, start: Int, pick: (Int) -> Boolean): (Int) -> Unit {
        val set = { s: Int -> items.forEachIndexed { i, t -> t.isSelected = (i == s) } }
        set(start)
        items.forEachIndexed { i, t -> t.setOnClickListener { if (pick(i)) set(i) } }
        return set
    }

    private fun setupUi() {
        // navigation
        v<View>(R.id.navLive).setOnClickListener { nav(0) }
        v<View>(R.id.navPlaylist).setOnClickListener { nav(1) }
        v<View>(R.id.navSettings).setOnClickListener { nav(2) }

        // source + destinations
        setSrc = group(listOf<TextView>(v(R.id.segCamera), v(R.id.segGallery)), 0) { setGallery(it == 1) }
        chips = listOf<TextView>(v(R.id.chipYT), v(R.id.chipFB), v(R.id.chipTW), v(R.id.chipKick), v(R.id.chipCustom))
        group(chips, platform) { i ->
            saveDest()
            platform = i
            loadDest()
            swUse.isChecked = useFlags[i]
            true
        }
        swUse.isChecked = useFlags[platform]
        swUse.setOnCheckedChangeListener { btn, c ->
            if (live) {
                if (useFlags[platform] != c) {
                    btn.isChecked = useFlags[platform]
                    toast(R.string.err_live_locked)
                }
                return@setOnCheckedChangeListener
            }
            useFlags[platform] = c
            save("use$platform", c)
            refreshChips()
        }
        v<View>(R.id.btnShowKey).setOnClickListener {
            val hidden = (etKey.inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0
            etKey.inputType = InputType.TYPE_CLASS_TEXT or
                (if (hidden) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
            etKey.setSelection(etKey.text.length)
        }
        btnGo.setOnClickListener { onGoLive() }
        btnFlip.setOnClickListener {
            try {
                camera.switchCamera()
                facing = if (facing == CameraHelper.Facing.BACK) CameraHelper.Facing.FRONT else CameraHelper.Facing.BACK
            } catch (e: Exception) {
            }
        }
        btnFlash.setOnClickListener {
            try {
                if (flashOn) camera.disableLantern() else camera.enableLantern()
                flashOn = !flashOn
                btnFlash.setColorFilter(ContextCompat.getColor(this, if (flashOn) R.color.teal else R.color.text))
            } catch (e: Exception) {
            }
        }
        btnMute.setOnClickListener { swMic.isChecked = !swMic.isChecked }

        // playlist
        v<View>(R.id.btnAddVideos).isSelected = true
        v<View>(R.id.btnAddVideos).setOnClickListener { pickVideos.launch(arrayOf("video/*")) }
        group(listOf<TextView>(v(R.id.segPlaylist), v(R.id.segLoop)), if (loopMode) 1 else 0) { i ->
            loopMode = (i == 1)
            save("loop", loopMode)
            files.setModes(loopMode, repeatAll, shuffle)
            true
        }
        val chipRepeat: TextView = v(R.id.chipRepeat)
        val chipShuffle: TextView = v(R.id.chipShuffle)
        chipRepeat.isSelected = repeatAll
        chipShuffle.isSelected = shuffle
        chipRepeat.setOnClickListener {
            repeatAll = !repeatAll
            chipRepeat.isSelected = repeatAll
            save("repeat", repeatAll)
            files.setModes(loopMode, repeatAll, shuffle)
        }
        chipShuffle.setOnClickListener {
            shuffle = !shuffle
            chipShuffle.isSelected = shuffle
            save("shuffle", shuffle)
            files.setModes(loopMode, repeatAll, shuffle)
        }
        btnStartPl.setOnClickListener {
            if (live) {
                if (gallery) stopLive() else toast(R.string.err_live_locked)
                return@setOnClickListener
            }
            nav(0)
            setSrc(1)
            setGallery(true)
            onGoLive()
        }

        // settings
        group(
            listOf<TextView>(v(R.id.langEn), v(R.id.langUr)),
            if (sp.getString("lang", "en") == "ur") 1 else 0
        ) { i ->
            if (locked()) {
                false
            } else {
                val tag = if (i == 1) "ur" else "en"
                save("lang", tag)
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
                true
            }
        }
        group(listOf<TextView>(v(R.id.res480), v(R.id.res720), v(R.id.res1080)), res) { i ->
            if (locked()) {
                false
            } else {
                res = i
                save("res", i)
                updateStats()
                restartPreview()
                true
            }
        }
        group(listOf<TextView>(v(R.id.fps24), v(R.id.fps30), v(R.id.fps60)), fps) { i ->
            if (locked()) {
                false
            } else {
                fps = i
                save("fps", i)
                updateStats()
                restartPreview()
                true
            }
        }
        group(listOf<TextView>(v(R.id.oriLand), v(R.id.oriPort)), if (land) 0 else 1) { i ->
            if (locked()) {
                false
            } else {
                land = (i == 0)
                save("land", land)
                requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                true
            }
        }

        val sb: SeekBar = v(R.id.sbBitrate)
        sb.max = 55
        sb.progress = (kbps - 500) / 100
        tvBitrate.text = "$kbps kbps"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (live) {
                    s.progress = (kbps - 500) / 100
                    return
                }
                kbps = 500 + p * 100
                tvBitrate.text = "$kbps kbps"
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                save("kbps", kbps)
            }
        })

        swMic.isChecked = !muted
        swMic.setOnCheckedChangeListener { _, checked ->
            muted = !checked
            save("muted", muted)
            applyAudio()
            updateMuteUi()
        }
        val swRe: SwitchCompat = v(R.id.swReconnect)
        swRe.isChecked = autoReconnect
        swRe.setOnCheckedChangeListener { _, c ->
            autoReconnect = c
            save("reconnect", c)
        }
        val swKeep: SwitchCompat = v(R.id.swKeepOn)
        swKeep.isChecked = keepOn
        swKeep.setOnCheckedChangeListener { _, c ->
            keepOn = c
            save("keepOn", c)
            applyKeepOn()
        }
        val swAd: SwitchCompat = v(R.id.swAdaptive)
        swAd.isChecked = adaptive
        swAd.setOnCheckedChangeListener { _, c ->
            adaptive = c
            save("adaptive", c)
        }

        // overlay
        swLogo.isChecked = logoOn
        swLogo.setOnCheckedChangeListener { _, c ->
            logoOn = c
            save("logoOn", c)
            if (c && sp.getString("logoPath", null) == null) toast(R.string.pick_logo_first)
            applyCameraOverlay()
        }
        v<View>(R.id.btnPickLogo).setOnClickListener { pickLogo.launch(arrayOf("image/*")) }
        swTicker.isChecked = tickerOn
        swTicker.setOnCheckedChangeListener { _, c ->
            tickerOn = c
            save("tickerOn", c)
            saveTicker()
            applyCameraOverlay()
        }
        etTicker.setText(tickerText)
        etTicker.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                saveTicker()
                applyCameraOverlay()
            }
        }
    }

    private fun nav(i: Int) {
        panelPlaylist.visibility = if (i == 1) View.VISIBLE else View.GONE
        panelSettings.visibility = if (i == 2) View.VISIBLE else View.GONE
        listOf(R.id.navLive, R.id.navPlaylist, R.id.navSettings).forEachIndexed { k, id ->
            findViewById<View>(id).isSelected = (k == i)
        }
    }

    // ------------------------------------------------------------------ settings storage

    private fun save(k: String, x: Int) = sp.edit().putInt(k, x).apply()
    private fun save(k: String, x: Boolean) = sp.edit().putBoolean(k, x).apply()
    private fun save(k: String, x: String) = sp.edit().putString(k, x).apply()

    private fun loadSettings() {
        platform = sp.getInt("platform", 0)
        for (i in 0 until 5) useFlags[i] = sp.getBoolean("use$i", i == platform)
        res = sp.getInt("res", 1)
        fps = sp.getInt("fps", 1)
        land = sp.getBoolean("land", false)
        kbps = sp.getInt("kbps", 2500)
        muted = sp.getBoolean("muted", false)
        autoReconnect = sp.getBoolean("reconnect", true)
        keepOn = sp.getBoolean("keepOn", true)
        adaptive = sp.getBoolean("adaptive", true)
        logoOn = sp.getBoolean("logoOn", false)
        tickerOn = sp.getBoolean("tickerOn", false)
        tickerText = sp.getString("tickerText", "Zarvimo Live Streamer") ?: "Zarvimo Live Streamer"
        loopMode = sp.getBoolean("loop", false)
        repeatAll = sp.getBoolean("repeat", true)
        shuffle = sp.getBoolean("shuffle", false)
        clips = Clips.load(sp)
        cur = sp.getInt("cur", 0)
        if (cur >= clips.size) cur = 0
    }

    private fun loadDest() {
        etServer.setText(sp.getString("srv$platform", servers[platform]))
        etKey.setText(sp.getString("key$platform", ""))
    }

    private fun saveDest() {
        sp.edit()
            .putInt("platform", platform)
            .putString("srv$platform", etServer.text.toString().trim())
            .putString("key$platform", etKey.text.toString().trim())
            .apply()
    }

    private fun saveTicker() {
        val t = etTicker.text.toString().trim()
        tickerText = if (t.isEmpty()) "Zarvimo Live Streamer" else t
        save("tickerText", tickerText)
    }

    private fun refreshChips() {
        chips.forEachIndexed { i, c ->
            c.text = platformNames[i] + (if (useFlags[i]) " ✓" else "")
        }
    }

    private fun urlFor(i: Int): String? {
        val server = (sp.getString("srv$i", servers[i]) ?: "").trim().trimEnd('/')
        val key = (sp.getString("key$i", "") ?: "").trim()
        if (server.isEmpty()) return null
        if (key.isEmpty()) return if (i == 4) server else null
        return "$server/$key"
    }

    // ------------------------------------------------------------------ permissions

    private fun hasPerms(): Boolean =
        listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO).all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun askPerms() {
        if (askingPerms) return
        askingPerms = true
        val p = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(p.toTypedArray())
    }

    // ------------------------------------------------------------------ camera preview + overlay

    private fun startPreview() {
        if (gallery || camera.isStreaming || camera.isOnPreview) return
        if (!hasPerms()) {
            askPerms()
            return
        }
        fitPreview()
        try {
            camera.startPreview(facing, resW[res], resH[res])
            ui.postDelayed({ applyCameraOverlay() }, 700)
        } catch (e: Exception) {
            toast(R.string.err_prepare)
        }
    }

    private fun restartPreview() {
        if (gallery || camera.isStreaming) return
        try {
            if (camera.isOnPreview) camera.stopPreview()
        } catch (e: Exception) {
        }
        ui.postDelayed({ startPreview() }, 350)
    }

    private fun fitPreview() {
        val frame: FrameLayout = v(R.id.previewFrame)
        frame.post {
            val fw = frame.width
            val fh = frame.height
            if (fw == 0 || fh == 0) return@post
            val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
            val ratio = if (portrait) 9f / 16f else 16f / 9f
            var w = fw
            var h = (fw / ratio).toInt()
            if (h > fh) {
                h = fh
                w = (fh * ratio).toInt()
            }
            glView.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
        }
    }

    private fun streamDims(): Pair<Int, Int> {
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        return if (portrait) Pair(resH[res], resW[res]) else Pair(resW[res], resH[res])
    }

    private fun logoBitmap(): Bitmap? {
        val path = sp.getString("logoPath", null) ?: return null
        return BitmapFactory.decodeFile(path)
    }

    private fun applyCameraOverlay() {
        if (gallery) return
        val dims = streamDims()
        overlay.refresh(
            glView, glView, dims.first, dims.second,
            if (logoOn) logoBitmap() else null,
            if (tickerOn) tickerText else null
        )
    }

    private fun attachFileOverlay(stream: Any, w: Int, h: Int) {
        if (!logoOn && !tickerOn) return
        val logo = if (logoOn) logoBitmap() else null
        val text = if (tickerOn) tickerText else null
        ui.postDelayed({
            if (live && gallery) {
                val gl = Compat.tryCall(stream, "getGlInterface") ?: stream
                overlay.refresh(stream, gl, w, h, logo, text)
            }
        }, 700)
    }

    private fun importLogo(uri: Uri) {
        Thread {
            try {
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bmp == null) {
                    runOnUiThread { toast(R.string.copy_fail) }
                } else {
                    val scale = minOf(1f, 512f / maxOf(bmp.width, bmp.height))
                    val out = if (scale < 1f) {
                        Bitmap.createScaledBitmap(
                            bmp,
                            (bmp.width * scale).toInt().coerceAtLeast(1),
                            (bmp.height * scale).toInt().coerceAtLeast(1),
                            true
                        )
                    } else {
                        bmp
                    }
                    val f = File(filesDir, "logo.png")
                    f.outputStream().use { s -> out.compress(Bitmap.CompressFormat.PNG, 100, s) }
                    runOnUiThread {
                        save("logoPath", f.absolutePath)
                        logoOn = true
                        save("logoOn", true)
                        swLogo.isChecked = true
                        applyCameraOverlay()
                        toast(R.string.logo_saved)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast(R.string.copy_fail) }
            }
        }.start()
    }

    private fun prepareCamera(): Boolean {
        val rotation = CameraHelper.getCameraOrientation(this)
        val ok = camera.prepareVideo(resW[res], resH[res], fpsVals[fps], kbps * 1024, 2, rotation) &&
            camera.prepareAudio(128 * 1024, 44100, true)
        if (ok) applyAudio()
        return ok
    }

    private fun applyAudio() {
        try {
            if (muted) camera.disableAudio() else camera.enableAudio()
        } catch (e: Exception) {
        }
    }

    private fun updateMuteUi() {
        btnMute.setColorFilter(ContextCompat.getColor(this, if (muted) R.color.red_text else R.color.text))
    }

    private fun setGallery(g: Boolean): Boolean {
        if (locked()) return false
        gallery = g
        if (g) {
            try {
                if (camera.isOnPreview) camera.stopPreview()
            } catch (e: Exception) {
            }
            glView.visibility = View.GONE
        } else {
            glView.visibility = View.VISIBLE
        }
        val camUi = if (g) View.GONE else View.VISIBLE
        btnMute.visibility = camUi
        btnFlip.visibility = camUi
        btnFlash.visibility = camUi
        tvHint.text = getString(if (g) R.string.preview_gallery else R.string.preview_camera)
        updateStats()
        return true
    }

    // ------------------------------------------------------------------ going live

    private fun locked(): Boolean {
        if (live) {
            toast(R.string.err_live_locked)
            return true
        }
        return false
    }

    private fun onGoLive() {
        if (live) {
            stopLive()
            return
        }
        saveDest()
        saveTicker()
        val urls = mutableListOf<String>()
        val names = mutableListOf<String>()
        for (i in 0 until 5) {
            if (!useFlags[i]) continue
            val u = urlFor(i)
            if (u == null) {
                toast(R.string.err_url_for, platformNames[i])
                return
            }
            urls.add(u)
            names.add(platformNames[i])
        }
        if (urls.isEmpty()) {
            toast(R.string.err_none_selected)
            return
        }
        if (!gallery && urls.size > 1) {
            toast(R.string.cam_one_dest, names[0])
            while (urls.size > 1) {
                urls.removeAt(1)
                names.removeAt(1)
            }
        }
        if (gallery) {
            if (clips.isEmpty()) {
                toast(R.string.err_no_clips)
                return
            }
        } else {
            if (!hasPerms()) {
                askPerms()
                return
            }
            if (!camera.isOnPreview) {
                toast(R.string.err_preview)
                return
            }
            if (!prepareCamera()) {
                toast(R.string.err_prepare)
                return
            }
        }
        destNames = names
        urlInUse = urls[0]
        live = true
        connected = false
        reconnectPending = false
        liveStart = 0L
        for (k in destUp.indices) destUp[k] = false
        setStatus(1)
        updateGoButtons()
        applyKeepOn()
        updateStats()
        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        if (gallery) {
            files.start(urls, clips, cur, loopMode, repeatAll, shuffle, kbps * 1024, adaptive, autoReconnect)
        } else {
            camAdapt = if (adaptive) BitrateAdapt(camera, kbps * 1024) else null
            camera.startStream(urlInUse)
        }
        ui.removeCallbacks(ticker)
        ui.postDelayed(ticker, 1000)
    }

    private fun stopLive() {
        live = false
        connected = false
        reconnectPending = false
        liveStart = 0L
        camAdapt = null
        ui.removeCallbacks(ticker)
        try {
            files.stop()
        } catch (e: Exception) {
        }
        try {
            if (camera.isStreaming) camera.stopStream()
        } catch (e: Exception) {
        }
        stopService(Intent(this, KeepAliveService::class.java))
        setStatus(0)
        updateGoButtons()
        applyKeepOn()
        updateStats()
    }

    private fun scheduleReconnect() {
        if (reconnectPending) return
        reconnectPending = true
        setStatus(3)
        ui.postDelayed({
            reconnectPending = false
            if (live && !connected) restartCamera()
        }, 3000)
    }

    private fun restartCamera() {
        if (gallery) return
        setStatus(3)
        try {
            camera.stopStream()
        } catch (e: Exception) {
        }
        if (prepareCamera()) camera.startStream(urlInUse) else stopLive()
    }

    private fun onClipStarted(i: Int) {
        cur = i
        save("cur", i)
        renderClips()
    }

    /** Gallery mode: per-destination connection state, reported by FileStreamer on the main thread. */
    private fun onDestState(dest: Int, ok: Boolean, reason: String?) {
        if (!live) return
        if (dest in destUp.indices) destUp[dest] = ok
        val any = destUp.any { it }
        connected = any
        if (any) {
            if (liveStart == 0L) liveStart = SystemClock.elapsedRealtime()
            setStatus(2)
        } else {
            setStatus(if (autoReconnect && reason != null) 3 else 1)
        }
        if (reason != null && !autoReconnect) {
            toast(R.string.stream_failed, destNames.getOrElse(dest) { "" } + ": " + reason)
        }
    }

    // ------------------------------------------------------------------ ConnectChecker (camera, background threads)

    override fun onConnectionStarted(url: String) {}

    override fun onConnectionSuccess() {
        runOnUiThread {
            if (!live || gallery) return@runOnUiThread
            connected = true
            reconnectPending = false
            if (liveStart == 0L) liveStart = SystemClock.elapsedRealtime()
            setStatus(2)
        }
    }

    override fun onConnectionFailed(reason: String) {
        runOnUiThread {
            if (gallery) return@runOnUiThread
            connected = false
            if (!live) return@runOnUiThread
            if (autoReconnect) {
                scheduleReconnect()
            } else {
                toast(R.string.stream_failed, reason)
                stopLive()
            }
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        camAdapt?.onSample()
        runOnUiThread { if (live && !gallery) updateStats(bitrate) }
    }

    override fun onDisconnect() {
        runOnUiThread { if (!gallery) connected = false }
    }

    override fun onAuthError() {
        runOnUiThread {
            if (live && !gallery) {
                toast(R.string.auth_error)
                stopLive()
            }
        }
    }

    override fun onAuthSuccess() {}

    // ------------------------------------------------------------------ small UI helpers

    private fun setStatus(s: Int) {
        val (txt, col) = when (s) {
            0 -> Pair(R.string.status_ready, R.color.teal)
            1 -> Pair(R.string.status_connecting, R.color.muted)
            2 -> Pair(R.string.status_live, R.color.red_text)
            else -> Pair(R.string.status_reconnecting, R.color.muted)
        }
        tvStatus.text = getString(txt)
        tvStatus.setTextColor(ContextCompat.getColor(this, col))
    }

    private fun updateStats(bps: Long = -1L) {
        val base = if (gallery) getString(R.string.src_gallery) else "${resH[res]}p · ${fpsVals[fps]} fps"
        tvStats.text = if (bps >= 0) {
            base + " · " + String.format(Locale.US, "%.1f Mbps", bps / 1_000_000.0)
        } else {
            base
        }
    }

    private fun updateGoButtons() {
        btnGo.text = getString(if (live) R.string.stop else R.string.go_live)
        btnStartPl.text = getString(if (live && gallery) R.string.stop else R.string.start_playlist)
        v<TextView>(R.id.tvNowLabel).text =
            getString(if (live && gallery) R.string.now_streaming else R.string.now_selected)
    }

    private fun applyKeepOn() {
        if (keepOn || live) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun toast(id: Int, vararg args: Any) {
        Toast.makeText(this, getString(id, *args), Toast.LENGTH_LONG).show()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) {
            String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
        } else {
            String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
        }
    }

    // ------------------------------------------------------------------ playlist

    private fun lockedGallery(): Boolean {
        if (live && gallery) {
            toast(R.string.err_live_locked)
            return true
        }
        return false
    }

    private fun importVideos(uris: List<Uri>) {
        if (uris.isEmpty()) return
        toast(R.string.copying, uris.size)
        Thread {
            val added = mutableListOf<Clip>()
            for (u in uris) {
                val c = Clips.copyIn(this, u)
                if (c != null) added.add(c)
            }
            runOnUiThread {
                clips.addAll(added)
                Clips.save(sp, clips)
                renderClips()
                if (added.size < uris.size) toast(R.string.copy_fail)
                if (added.isNotEmpty()) toast(R.string.copy_done, added.size)
            }
        }.start()
    }

    private fun removeClip(i: Int) {
        if (lockedGallery() || i !in clips.indices) return
        Clips.delete(clips[i])
        clips.removeAt(i)
        if (i < cur) cur--
        if (cur >= clips.size) cur = 0
        save("cur", cur)
        Clips.save(sp, clips)
        renderClips()
    }

    private fun moveClip(i: Int, delta: Int) {
        if (lockedGallery()) return
        val j = i + delta
        if (i !in clips.indices || j !in clips.indices) return
        val c = clips.removeAt(i)
        clips.add(j, c)
        if (cur == i) cur = j else if (cur == j) cur = i
        save("cur", cur)
        Clips.save(sp, clips)
        renderClips()
    }

    private fun renderClips() {
        val list: LinearLayout = v(R.id.clipList)
        list.removeAllViews()
        clips.forEachIndexed { i, c ->
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(ContextCompat.getColor(this, R.color.line))
                line.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                list.addView(line)
            }
            val row = layoutInflater.inflate(R.layout.item_clip, list, false)
            val name = row.findViewById<TextView>(R.id.tvName)
            name.text = c.name
            name.setTextColor(ContextCompat.getColor(this, if (i == cur) R.color.teal else R.color.text))
            row.findViewById<TextView>(R.id.tvDur).text = fmt(c.durationMs)
            if (c.thumb.isNotEmpty()) {
                row.findViewById<ImageView>(R.id.ivThumb).setImageBitmap(BitmapFactory.decodeFile(c.thumb))
            }
            val up = row.findViewById<View>(R.id.btnUp)
            val down = row.findViewById<View>(R.id.btnDown)
            up.alpha = if (i == 0) 0.25f else 1f
            down.alpha = if (i == clips.size - 1) 0.25f else 1f
            up.setOnClickListener { moveClip(i, -1) }
            down.setOnClickListener { moveClip(i, 1) }
            row.findViewById<View>(R.id.btnRemove).setOnClickListener { removeClip(i) }
            row.setOnClickListener {
                if (!lockedGallery()) {
                    cur = i
                    save("cur", i)
                    renderClips()
                }
            }
            list.addView(row)
        }
        val has = clips.isNotEmpty()
        list.visibility = if (has) View.VISIBLE else View.GONE
        v<View>(R.id.cardNow).visibility = if (has) View.VISIBLE else View.GONE
        v<View>(R.id.tvEmpty).visibility = if (has) View.GONE else View.VISIBLE
        v<TextView>(R.id.tvNowName).text = clips.getOrNull(cur)?.name ?: ""
        val total = clips.sumOf { it.durationMs }
        v<TextView>(R.id.tvSummary).text = if (has) getString(R.string.summary, clips.size, fmt(total)) else ""
        updateGoButtons()
    }
}
