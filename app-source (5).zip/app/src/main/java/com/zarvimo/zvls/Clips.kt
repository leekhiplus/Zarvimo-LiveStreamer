package com.zarvimo.zvls

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Clip(val path: String, val name: String, val durationMs: Long, val thumb: String)

/** Gallery videos are copied into app storage so the encoder can read them by plain file path. */
object Clips {

    fun load(sp: SharedPreferences): MutableList<Clip> {
        val out = mutableListOf<Clip>()
        try {
            val arr = JSONArray(sp.getString("clips", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val path = o.getString("path")
                if (File(path).exists()) {
                    out.add(Clip(path, o.getString("name"), o.getLong("dur"), o.optString("thumb", "")))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(sp: SharedPreferences, list: List<Clip>) {
        val arr = JSONArray()
        for (c in list) {
            arr.put(
                JSONObject()
                    .put("path", c.path)
                    .put("name", c.name)
                    .put("dur", c.durationMs)
                    .put("thumb", c.thumb)
            )
        }
        sp.edit().putString("clips", arr.toString()).apply()
    }

    fun delete(c: Clip) {
        File(c.path).delete()
        if (c.thumb.isNotEmpty()) File(c.thumb).delete()
    }

    fun copyIn(ctx: Context, uri: Uri): Clip? {
        return try {
            var name = "video_" + System.currentTimeMillis() + ".mp4"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (n != null) name = n
                }
            }
            val dir = File(ctx.filesDir, "clips")
            dir.mkdirs()
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val out = File(dir, System.currentTimeMillis().toString() + "_" + safe)
            val input = ctx.contentResolver.openInputStream(uri) ?: return null
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }

            var dur = 0L
            var thumb = ""
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(out.absolutePath)
                dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val frame = mmr.getFrameAtTime(1_000_000L)
                if (frame != null) {
                    val t = File(dir, out.name + ".jpg")
                    val small = Bitmap.createScaledBitmap(frame, 112, 80, true)
                    t.outputStream().use { s -> small.compress(Bitmap.CompressFormat.JPEG, 80, s) }
                    thumb = t.absolutePath
                }
            } finally {
                mmr.release()
            }
            Clip(out.absolutePath, name, dur, thumb)
        } catch (e: Exception) {
            null
        }
    }
}
