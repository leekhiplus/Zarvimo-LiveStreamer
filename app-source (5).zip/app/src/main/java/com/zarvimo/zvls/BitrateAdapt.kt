package com.zarvimo.zvls

/**
 * Simple adaptive bitrate: lowers the encoder bitrate when RootEncoder reports congestion
 * and slowly raises it again (never above the user's chosen bitrate) when the link is healthy.
 * If the library does not expose congestion info, it silently does nothing.
 */
class BitrateAdapt(private val target: Any, private val maxBps: Int) {

    private val minBps = (maxBps / 4).coerceAtLeast(400_000).coerceAtMost(maxBps)
    private var current = maxBps
    private var good = 0
    private var broken = false

    private fun congested(): Boolean? {
        return try {
            val client = Compat.call(target, "getStreamClient") ?: return null
            Compat.call(client, "hasCongestion") as? Boolean
        } catch (t: Throwable) {
            null
        }
    }

    /** Call about once per second (from onNewBitrate). */
    fun onSample() {
        if (broken) return
        val c = congested()
        if (c == null) {
            broken = true
            return
        }
        val next: Int = if (c) {
            good = 0
            (current * 0.75f).toInt()
        } else {
            good++
            if (good >= 12) {
                good = 0
                (current * 1.15f).toInt()
            } else {
                current
            }
        }
        val bounded = next.coerceIn(minBps, maxBps)
        if (bounded != current) {
            current = bounded
            try {
                Compat.call(target, "setVideoBitrateOnFly", bounded)
            } catch (t: Throwable) {
                broken = true
            }
        }
    }
}
