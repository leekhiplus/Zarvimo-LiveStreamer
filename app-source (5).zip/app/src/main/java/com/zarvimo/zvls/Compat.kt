package com.zarvimo.zvls

import android.util.Log

/**
 * Reflection helpers. RootEncoder overlay / bitrate calls are looked up at runtime,
 * so a method that is missing in some library version never breaks the build.
 */
object Compat {

    private fun box(c: Class<*>): Class<*> = when (c) {
        Int::class.javaPrimitiveType -> Int::class.javaObjectType
        Float::class.javaPrimitiveType -> Float::class.javaObjectType
        Long::class.javaPrimitiveType -> Long::class.javaObjectType
        Boolean::class.javaPrimitiveType -> Boolean::class.javaObjectType
        Double::class.javaPrimitiveType -> Double::class.javaObjectType
        else -> c
    }

    private fun fits(p: Array<Class<*>>, a: Array<out Any?>): Boolean {
        for (i in p.indices) {
            val v = a[i]
            if (v != null && !box(p[i]).isInstance(v)) return false
        }
        return true
    }

    /** Calls a public method by name and argument count/type. Throws if none matches. */
    fun call(target: Any, name: String, vararg args: Any?): Any? {
        val m = target.javaClass.methods.firstOrNull {
            it.name == name && it.parameterTypes.size == args.size && fits(it.parameterTypes, args)
        } ?: throw NoSuchMethodException(name + "/" + args.size)
        return m.invoke(target, *args)
    }

    /** Same as call() but returns null instead of throwing. */
    fun tryCall(target: Any?, name: String, vararg args: Any?): Any? {
        if (target == null) return null
        return try {
            call(target, name, *args)
        } catch (t: Throwable) {
            Log.w("ZVLS", "reflect $name failed: $t")
            null
        }
    }
}
