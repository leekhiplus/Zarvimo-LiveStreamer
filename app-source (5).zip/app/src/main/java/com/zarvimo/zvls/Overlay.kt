package com.zarvimo.zvls

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.util.Log

/**
 * Logo watermark + scrolling text ticker, drawn with RootEncoder's OpenGL object filters.
 * Everything goes through reflection (see Compat), so nothing here can break the build.
 */
class Overlay {

    private class Item(val owner: Any, val text: Any, val widthPct: Float, val yPct: Float, var x: Float)

    private val pkg = "com.pedro.encoder.input.gl.render.filters.object."
    private val items = mutableListOf<Item>()
    private val handler = Handler(Looper.getMainLooper())
    private var looping = false

    private val tick = object : Runnable {
        override fun run() {
            val dead = mutableListOf<Item>()
            for (item in items) {
                item.x -= 0.36f
                if (item.x < -item.widthPct) item.x = 100f
                try {
                    Compat.call(item.text, "setPosition", item.x, item.yPct)
                } catch (t: Throwable) {
                    dead.add(item)
                }
            }
            items.removeAll(dead)
            if (items.isNotEmpty()) handler.postDelayed(this, 40) else looping = false
        }
    }

    /**
     * Replaces all overlay filters on [gl] (an OpenGlView or a stream's GL interface).
     * [owner] identifies the stream so its ticker animation can be dropped later.
     */
    fun refresh(owner: Any, gl: Any, w: Int, h: Int, logo: Bitmap?, ticker: String?) {
        items.removeAll { it.owner === owner }
        removeFilters(gl)
        if (w <= 0 || h <= 0) return
        try {
            if (logo != null) addLogo(gl, w, h, logo)
            if (!ticker.isNullOrBlank()) addTicker(owner, gl, w, h, ticker)
        } catch (t: Throwable) {
            Log.w("ZVLS", "overlay failed: $t")
        }
        if (items.isNotEmpty() && !looping) {
            looping = true
            handler.postDelayed(tick, 40)
        }
    }

    /** The stream is gone: just forget its ticker animation. */
    fun forget(owner: Any) {
        items.removeAll { it.owner === owner }
    }

    fun stopAll() {
        items.clear()
        handler.removeCallbacks(tick)
        looping = false
    }

    private fun removeFilters(gl: Any) {
        try {
            Compat.call(gl, "clearFilters")
        } catch (t: Throwable) {
            try {
                val none = Class.forName("com.pedro.encoder.input.gl.render.filters.NoFilterRender")
                    .getDeclaredConstructor().newInstance()
                Compat.call(gl, "setFilter", none)
            } catch (e: Throwable) {
                // nothing to clear
            }
        }
    }

    private fun addFilter(gl: Any, f: Any) {
        try {
            Compat.call(gl, "addFilter", f)
        } catch (t: Throwable) {
            Compat.call(gl, "setFilter", f)
        }
    }

    private fun addLogo(gl: Any, w: Int, h: Int, logo: Bitmap) {
        val width = (w * 0.14f).toInt().coerceAtLeast(32)
        val height = (width * logo.height.toFloat() / logo.width).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createScaledBitmap(logo, width, height, true)
        val f = Class.forName(pkg + "ImageObjectFilterRender").getDeclaredConstructor().newInstance()
        addFilter(gl, f)
        Compat.call(f, "setImage", bmp)
        val px = 100f * width / w
        val py = 100f * height / h
        Compat.call(f, "setScale", px, py)
        Compat.call(f, "setPosition", 100f - px - 2f, 3f)
    }

    private fun addTicker(owner: Any, gl: Any, w: Int, h: Int, text: String) {
        val size = (h * 0.045f).coerceAtLeast(18f)
        val f = Class.forName(pkg + "TextObjectFilterRender").getDeclaredConstructor().newInstance()
        addFilter(gl, f)
        Compat.call(f, "setText", text, size, Color.WHITE)
        try {
            Compat.call(f, "setDefaultScale", w, h)
        } catch (t: Throwable) {
            // older versions size the text automatically
        }
        val widthPct = text.length * size * 0.55f * 100f / w
        val y = 100f - (size * 1.5f * 100f / h) - 3f
        Compat.call(f, "setPosition", 100f, y)
        items.add(Item(owner, f, widthPct, y, 100f))
    }
}
