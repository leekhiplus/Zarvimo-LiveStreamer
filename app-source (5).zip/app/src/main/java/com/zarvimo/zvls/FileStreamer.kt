package com.zarvimo.zvls

import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.decoder.AudioDecoderInterface
import com.pedro.encoder.input.decoder.VideoDecoderInterface
import com.pedro.library.rtmp.RtmpFromFile

/**
 * Streams gallery clips (single loop or playlist) to one or several RTMP destinations.
 * Every destination runs its own RootEncoder RtmpFromFile (own decoder + encoder).
 * Between playlist clips the connections are re-opened (short gap of 1-3 seconds).
 */
class FileStreamer(private val cb: Callbacks) {

    interface Callbacks {
        fun onClip(index: Int)
        fun onEnd()
        fun onClipError(name: String)
        fun onDest(dest: Int, connected: Boolean, reason: String?)
        fun onBitrate(totalBps: Long)
        fun onAttach(stream: Any, w: Int, h: Int)
        fun onDetach(stream: Any)
    }

    private class Dest(val url: String) {
        var rtmp: RtmpFromFile? = null
        var rate = 0L
        var adapt: BitrateAdapt? = null
        var failing = false
        var retryScheduled = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var dests: List<Dest> = emptyList()
    private var clips: List<Clip> = emptyList()
    private var index = 0
    private var bitrate = 2_500_000
    private var loopOne = false
    private var repeatAll = true
    private var shuffle = false
    private var adaptive = true
    private var autoReconnect = true
    private var fails = 0
    private var active = false

    fun start(
        urls: List<String>, clips: List<Clip>, from: Int,
        loopOne: Boolean, repeatAll: Boolean, shuffle: Boolean,
        bitrate: Int, adaptive: Boolean, autoReconnect: Boolean
    ) {
        stopAll()
        this.dests = urls.map { Dest(it) }
        this.clips = clips.toList()
        this.index = if (clips.isEmpty()) 0 else from.coerceIn(0, clips.size - 1)
        this.loopOne = loopOne
        this.repeatAll = repeatAll
        this.shuffle = shuffle
        this.bitrate = bitrate
        this.adaptive = adaptive
        this.autoReconnect = autoReconnect
        this.fails = 0
        this.active = true
        play()
    }

    fun setModes(loopOne: Boolean, repeatAll: Boolean, shuffle: Boolean) {
        this.loopOne = loopOne
        this.repeatAll = repeatAll
        this.shuffle = shuffle
        for (d in dests) {
            try {
                d.rtmp?.setLoopMode(loopOne)
            } catch (e: Exception) {
            }
        }
    }

    fun stop() {
        active = false
        stopAll()
        dests = emptyList()
    }

    private fun stopAll() {
        for (d in dests) stopDest(d)
    }

    private fun stopDest(d: Dest) {
        val r = d.rtmp
        d.rtmp = null
        d.adapt = null
        d.rate = 0L
        if (r != null) {
            cb.onDetach(r)
            try {
                if (r.isStreaming) r.stopStream()
            } catch (e: Exception) {
            }
        }
    }

    private fun isLeader(d: Dest): Boolean =
        dests.firstOrNull { it.rtmp != null && !it.failing } === d

    private fun startDest(i: Int, d: Dest, clip: Clip): Boolean {
        val checker = object : ConnectChecker {
            override fun onConnectionStarted(url: String) {}
            override fun onConnectionSuccess() {
                handler.post {
                    d.failing = false
                    cb.onDest(i, true, null)
                }
            }

            override fun onConnectionFailed(reason: String) {
                handler.post { onDestFailed(i, d, reason) }
            }

            override fun onNewBitrate(bitrate: Long) {
                d.rate = bitrate
                d.adapt?.onSample()
                handler.post {
                    var total = 0L
                    for (x in dests) total += x.rate
                    cb.onBitrate(total)
                }
            }

            override fun onDisconnect() {}
            override fun onAuthError() {
                handler.post { cb.onDest(i, false, "auth") }
            }

            override fun onAuthSuccess() {}
        }
        val videoDone = object : VideoDecoderInterface {
            override fun onVideoDecoderFinished() {
                if (active && !loopOne) {
                    handler.post {
                        if (active && !loopOne && isLeader(d)) next()
                    }
                }
            }
        }
        val audioDone = object : AudioDecoderInterface {
            override fun onAudioDecoderFinished() {}
        }
        val r = RtmpFromFile(checker, videoDone, audioDone)
        if (!prepareVideoCompat(r, clip.path, bitrate)) return false
        try {
            r.prepareAudio(clip.path, 128 * 1024)
        } catch (e: Exception) {
            // file without usable audio: stream video only
        }
        r.setLoopMode(loopOne)
        d.rtmp = r
        d.failing = false
        d.adapt = if (adaptive) BitrateAdapt(r, bitrate) else null
        r.startStream(d.url)
        val size = clipSize(clip.path)
        cb.onAttach(r, size.first, size.second)
        return true
    }

    private fun play() {
        val clip = clips.getOrNull(index)
        if (clip == null) {
            finish()
            return
        }
        var started = 0
        dests.forEachIndexed { i, d -> if (startDest(i, d, clip)) started++ }
        if (started == 0) {
            cb.onClipError(clip.name)
            fails++
            if (fails >= clips.size) finish() else next()
            return
        }
        fails = 0
        cb.onClip(index)
    }

    private fun finish() {
        active = false
        stopAll()
        cb.onEnd()
    }

    private fun next() {
        stopAll()
        val n = clips.size
        if (n == 0) {
            finish()
            return
        }
        if (shuffle && n > 1) {
            var r = index
            while (r == index) r = (0 until n).random()
            index = r
        } else {
            index++
            if (index >= n) {
                if (repeatAll) {
                    index = 0
                } else {
                    finish()
                    return
                }
            }
        }
        play()
    }

    private fun onDestFailed(i: Int, d: Dest, reason: String) {
        if (!active || d.rtmp == null) return
        d.failing = true
        cb.onDest(i, false, reason)
        if (autoReconnect) {
            if (d.retryScheduled) return
            d.retryScheduled = true
            handler.postDelayed({
                d.retryScheduled = false
                if (active && d.failing) {
                    stopDest(d)
                    val clip = clips.getOrNull(index)
                    if (clip == null || !startDest(i, d, clip)) {
                        if (dests.all { it.rtmp == null }) finish()
                    }
                }
            }, 3000)
        } else {
            stopDest(d)
            if (dests.all { it.rtmp == null }) finish()
        }
    }

    private fun clipSize(path: String): Pair<Int, Int> {
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(path)
            val w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            val h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) Pair(h, w) else Pair(w, h)
        } catch (e: Exception) {
            Pair(1280, 720)
        } finally {
            mmr.release()
        }
    }

    /**
     * RootEncoder 2.4.x changed the prepareVideo overloads between releases, so the
     * String-path overload is looked up at runtime instead of being hard-coded.
     */
    private fun prepareVideoCompat(r: RtmpFromFile, path: String, bitrate: Int): Boolean {
        val m = r.javaClass.methods
            .filter { it.name == "prepareVideo" && it.parameterTypes.isNotEmpty() && it.parameterTypes[0] == String::class.java }
            .minByOrNull { it.parameterTypes.size } ?: return false
        var bitrateUsed = false
        val args = m.parameterTypes.mapIndexed { i, t ->
            when {
                i == 0 -> path
                t == Int::class.javaPrimitiveType && !bitrateUsed -> {
                    bitrateUsed = true
                    bitrate
                }
                t == Int::class.javaPrimitiveType -> 0
                t == Boolean::class.javaPrimitiveType -> false
                else -> null
            }
        }.toTypedArray()
        return try {
            (m.invoke(r, *args) as? Boolean) ?: false
        } catch (e: Exception) {
            false
        }
    }
}
